ALTER TABLE %%PREFIX%%jacl2_group ALTER COLUMN id_aclgrp TYPE character varying(60);
ALTER TABLE %%PREFIX%%jacl2_user_group ALTER COLUMN id_aclgrp TYPE character varying(60);
ALTER TABLE %%PREFIX%%jacl2_rights ALTER COLUMN id_aclgrp TYPE character varying(60);
