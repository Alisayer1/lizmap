DROP TABLE IF EXISTS `%%PREFIX%%jacl_group`;
DROP TABLE IF EXISTS `%%PREFIX%%jacl_right_values`;
DROP TABLE IF EXISTS `%%PREFIX%%jacl_right_values_group`;
DROP TABLE IF EXISTS `%%PREFIX%%jacl_rights`;
DROP TABLE IF EXISTS `%%PREFIX%%jacl_subject`;
DROP TABLE IF EXISTS `%%PREFIX%%jacl_user_group`;
