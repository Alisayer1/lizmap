<?php

$locales = array(

    'title'=>'Welcome',
    'instruction'=>'Click on the "next" button to start the installation of the application',

);
