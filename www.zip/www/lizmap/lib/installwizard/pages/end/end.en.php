<?php

$locales = array(

  'title'=>'End',
  'finish'=>'The installation is finished',

);
