<?php
/**
 * @package     jelix-scripts
 * @author      Laurent Jouanneau
 * @copyright   2018 Laurent Jouanneau
 * @link        https://jelix.org
 * @licence     GNU General Public Licence see LICENCE file or http://www.gnu.org/licenses/gpl.html
 */

$commandName = 'setinivalue';

require (__DIR__.'/includes/scripts.inc.php');
